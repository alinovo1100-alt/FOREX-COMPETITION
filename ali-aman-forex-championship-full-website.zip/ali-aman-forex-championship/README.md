# ALI AMAN FOREX CHAMPIONSHIP 2026

Responsive single-page website for an educational, demo-only trading competition.

## Included features
1. Rulebook: eligibility, trading limits, scoring, fair play, disqualification, appeals and schedule.
2. Participant registration: display name, participant ID and demo platform.
3. Automatic leaderboard: ranks saved results by score, then drawdown and return.
4. Participant profiles: public-style profile view using the locally registered demo data.
5. Certificates: create a printable recognition certificate and use browser Print → Save as PDF.
6. Organizer dashboard: enter verified scores, export leaderboard CSV and reset local demo data.

## Important prototype limitations
- Registration and results are stored in the current browser using localStorage only. They do not sync across devices and are not submitted to an organizer.
- The organizer dashboard has NO authentication. Anyone who can access this browser can edit its demo data.
- Do not use this prototype to collect passwords, email addresses, identity documents or other sensitive personal data.
- A real multi-user public competition needs a secure backend, database, authenticated organizer roles, server-side validation, audit logs and privacy safeguards.
- This is an educational demo-only event. No real-money trading, deposits, entry fees or cash prizes.

## Publish using GitHub Pages
1. Create a public repository named `ali-aman-forex-championship`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open Settings → Pages.
4. Choose Deploy from a branch, branch `main`, folder `/ (root)`, then Save.
5. GitHub will display the published website URL in Settings → Pages.

## Before launch
Set exact competition dates, time zone, approved demo platform/instruments, drawdown measurement method, and a precise scoring worksheet. Publish them before registration closes.
